# blueprism
BP project Guide
https://github.com/ashz30/blueprism/blob/master/guide/BP%20Auto-Deployment%20Cookbook%20BP-GIT-Jenkins%20v2.pdf

